﻿'use strict';
module DeBiese.NgResources.Part1.Resources {
    export class Errors {
        static unExpectedError: string = 'An unexpected error occurred. Contact IT support if the error persists.';
    }
}