﻿'use strict';
module DeBiese.NgResources.Part1.Resources {
    export class Help {
        static title: string = 'Help';
        static helpText: string = 'Contact developers@spikes.be when you encounter problems or errors.';
    }
}