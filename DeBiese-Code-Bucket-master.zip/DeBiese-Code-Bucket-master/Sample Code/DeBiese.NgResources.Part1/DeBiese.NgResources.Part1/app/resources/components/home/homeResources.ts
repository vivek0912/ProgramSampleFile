﻿'use strict';
module DeBiese.NgResources.Part1.Resources {
    export class Home {
        static title: string = 'Home Title';
        static helloWorld: string = 'Hello World!';
    }
}