﻿'use strict';
module DeBiese.NgResources.Part1.Resources {
    export class Navigation {
        static title: string = 'DeBiese.NgResources.Part1';
        static navItemHome: string = 'Home';
        static navItemHelp: string = 'Help';
    }
}