﻿/// <reference path="../_app.ts" />
'use strict';
module DeBiese.WinAuth.NG.Common.Configuration {
    export class AppConfig {
        static serviceBaseUrl: string = 'http://localhost:30014/';
    }
}