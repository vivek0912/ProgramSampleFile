export const environment = {
  production: true,
  serviceBaseUrl: 'http://localhost:30014/'
};
