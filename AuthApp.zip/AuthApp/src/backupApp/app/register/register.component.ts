import { Component, OnInit } from '@angular/core';
import { AuthService } from '../_services/auth.service';
import { User } from '../_model/user';
import { RouterStateSnapshot, Router } from '@angular/router';
import { slideInOutAnimation } from '../_animations/slide-in-out.animation';
import { PromptComponent } from '../_component/prompt/prompt.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ModalService } from '../_services/modal.service';
import { DialogService } from '../_services/dialog.service';
import { Subscription } from 'rxjs';
import { PageService } from '../_services/page.service';

@Component({
  selector: 'app-register',
  // make slide in/out animation available to this component
  //animations: [slideInOutAnimation],

  // attach the slide in/out animation to the host (root) element of this component
  host: { '[@slideInOutAnimation]': '' },
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit  {

  component: any;
  subscription: Subscription;
  registerResult: number = 0;
  registerUserData = new User();// = { email: '', username: '', firstname: '', lastname: '', password: ''};
  constructor(private _authservice: AuthService, private router: Router, private dialogService: DialogService,private pageService: PageService) {  
    // redirect to home if already logged in
      if (this._authservice.currentUserValue) { 
        this.router.navigate(['/paidevents']);
    }

    this.subscription = this.pageService.getDialog().subscribe(page => {
      if (page) {
        this.open(page);
      } else {
        // do something
      }
    });
  }

  ngOnInit(): void {
    this.registerUserData.username 
      = this.registerUserData.firstName 
      = this.registerUserData.lastName 
      = this.registerUserData.password 
      = ""
  }

  ValidateUser(user){
    if(user.username == "" || user.firstname=="" || user.lastname == "" || user.password == "") return false;
    return true;
  }
  Register(user){
    if(!this.ValidateUser(user)) {
      this.dialogService.sendAlert({type:2, message: "Required Fields must be filled.."});
      return;
    }
    console.log(user);
    this._authservice.registerUser(user).subscribe(data=>
      {
        console.log("login Details:", data);
        this.dialogService.sendAlert({type: 4, message: data});
        //this.router.navigate(['/login'], { queryParams: { }});
      },
      error => {
        console.log("Error: ", error);
        this.dialogService.sendAlert({type: 3, message: error});
      },
      ()=>{
        console.log("login process complete!");
      });
    console.log('Logged in!');
  }

 open(page){
   switch(page.type)
   {
     case 1:
      this.router.navigate(['/login'], { queryParams: { }});
      break;
      default:
        console.log('some data here..');
   }
 }

}
