import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class PageService {
    private pageSubject = new Subject<any>();
    
    sendAlert(dialog: {type: number, message: string}) {
        this.pageSubject.next(dialog);
    }

    clearAlert() {
        this.pageSubject.next();
    }

    getDialog(): Observable<any> {
        return this.pageSubject.asObservable();
    }
}