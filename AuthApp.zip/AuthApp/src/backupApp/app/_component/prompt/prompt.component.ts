import {Component, OnInit, Input, ViewChild, ElementRef, SimpleChanges} from '@angular/core';

import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { ModalService } from 'src/app/_services/modal.service';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { DialogService } from 'src/app/_services/dialog.service';
import { Subscription } from 'rxjs';
import { PageService } from 'src/app/_services/page.service';

@Component({
  selector: 'app-prompt',
  templateUrl: './prompt.component.html',
  styleUrls: ['./prompt.component.css']
})
export class PromptComponent implements OnInit {
  @Input() result: number;
  subscription: Subscription;
  @ViewChild('content') contentRef: ElementRef;
  @ViewChild('dialog_required') dialog_required: ElementRef;
  @ViewChild('dialog_serverError') dialog_serverError: ElementRef;
  @ViewChild('dialog_success') dialog_success: ElementRef;

  closeResult = '';
  serverError = '';
  serverResponse = '';

  constructor(private modalService: ModalService, private dialogService: DialogService, private pageService: PageService) {
    this.result = 0;
    this.subscription = this.dialogService.getDialog().subscribe(dialog => {
      if (dialog) {
        this.open(dialog);
      }
    });
  }

  open(dialogType) {
    switch(dialogType.type)
    {
        case 1:
          this.modalService.open(this.contentRef).then(data=>{
            this.closeResult = data;
          });
          break;
        case 2:
          this.modalService.open(this.dialog_required).then(data=>{
            this.closeResult = data;
          });
           break;
        case 3:
          this.serverError = dialogType.message;
          this.modalService.open(this.dialog_serverError).then(data=>{
            this.closeResult = data;            
          });
          break;
        case 4:
          this.serverResponse = dialogType.message;
          this.modalService.open(this.dialog_success).then(data=>{
            this.closeResult = data;        
            this.pageService.sendAlert({type: 1, message: "page"})    
          });
          break;
        default:
          console.log('no modal opens');
    }      
    
  } 

  ngOnInit(): void {
    console.log(this.result)
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
}
}
